[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\dev_repos\payvexity\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>