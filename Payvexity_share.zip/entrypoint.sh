#!/bin/bash
service nginx start
php-fpm
