<?php

namespace App\Models\Payments;

use Illuminate\Database\Eloquent\Model;

class OnlinePaymentLinks extends Model
{

    //
}
