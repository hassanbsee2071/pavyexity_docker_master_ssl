<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserModules extends Model
{
    //
}
