<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmtpSettingModel extends Model
{
    protected $table = "smtp_setting";
}
