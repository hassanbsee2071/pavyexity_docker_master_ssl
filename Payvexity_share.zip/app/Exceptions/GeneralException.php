<?php namespace App\Exceptions;

/**
 * Class GeneralException
 *
 */

use Exception;

class GeneralException extends Exception {}