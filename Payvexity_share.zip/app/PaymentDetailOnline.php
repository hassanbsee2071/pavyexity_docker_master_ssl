<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentDetailOnline extends Model
{
    protected $table = "online_payment_details";
    public $timestamps = false;
}
